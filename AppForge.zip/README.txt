AppForge - בונה אפליקציות אופליין (גרסה 0.2.5)
פתח את התיקייה ב-Android Studio (או gradle עם JDK 17) והרץ: assembleDebug על המודול app.
נדרש אינטרנט רק בקומפילציה. מבנה: app = הבונה, runtime = התבנית, shared = גשר Forge ואייקון.


בנייה בגייטהאב: העלה את כל תוכן התיקייה (כולל .github) למאגר. בלשונית Actions הרץ Build APK, ובסיומו הורד את AppForge-apk מתוך Artifacts.
