package com.appforge.builder;

import android.content.Context;
import android.os.Environment;
import com.android.apksig.ApkSigner;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.zip.*;

/** לוקח את template.apk, מחליף את assets/www/index.html, משנה שם חבילה (באורך זהה), מיישר וחותם. */
public class Packager {
    static class Count extends FilterOutputStream {
        long n; Count(OutputStream o) { super(o); }
        @Override public void write(int b) throws IOException { out.write(b); n++; }
        @Override public void write(byte[] b, int o, int l) throws IOException { out.write(b, o, l); n += l; }
    }

    public static String build(Context c, String html, String name) throws Exception {
        String safe = name.replaceAll("[^\\p{L}\\p{N}_-]", "_");
        File tpl = new File(c.getCacheDir(), "t.apk"), un = new File(c.getCacheDir(), "u.apk");
        File dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS); dl.mkdirs();
        File out = new File(dl, safe + ".apk");
        try (InputStream in = c.getAssets().open("template.apk")) { java.nio.file.Files.copy(in, tpl.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
        String pkg = "com.forge.g" + String.format("%04d", (int) (System.currentTimeMillis() / 1000 % 10000));
        rezip(tpl, un, html, pkg);
        KeyStore ks = KeyStore.getInstance("PKCS12");
        try (InputStream in = c.getAssets().open("forge.p12")) { ks.load(in, "forge123".toCharArray()); }
        PrivateKey k = (PrivateKey) ks.getKey("forge", "forge123".toCharArray());
        X509Certificate cert = (X509Certificate) ks.getCertificate("forge");
        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder("forge", k, Collections.singletonList(cert)).build();
        new ApkSigner.Builder(Collections.singletonList(sc)).setInputApk(un).setOutputApk(out).setMinSdkVersion(26)
            .setV1SigningEnabled(false).setV2SigningEnabled(true).setV3SigningEnabled(true).build().sign();
        return out.getPath();
    }

    static void rezip(File in, File out, String html, String pkg) throws Exception {
        try (ZipFile z = new ZipFile(in); Count co = new Count(new FileOutputStream(out)); ZipOutputStream zo = new ZipOutputStream(co)) {
            for (Enumeration<? extends ZipEntry> e = z.entries(); e.hasMoreElements();) {
                ZipEntry s = e.nextElement(); String n = s.getName();
                if (n.startsWith("META-INF/") || n.equals("assets/www/index.html")) continue;
                ZipEntry d = new ZipEntry(n);
                byte[] data;
                try (InputStream is = z.getInputStream(s)) { data = readAll(is); }
                if (n.equals("AndroidManifest.xml")) data = patch(data, "com.forge.g0000", pkg);
                if (s.getMethod() == ZipEntry.STORED) {   // יישור ל-4 בתים (חובה ל-resources.arsc)
                    d.setMethod(ZipEntry.STORED); d.setSize(data.length); d.setCompressedSize(data.length);
                    CRC32 crc = new CRC32(); crc.update(data); d.setCrc(crc.getValue());
                    int pad = (int) ((4 - ((co.n + 30 + n.getBytes(StandardCharsets.UTF_8).length + 4) % 4)) % 4);
                    byte[] ex = new byte[4 + pad]; ex[0] = (byte) 0x35; ex[1] = (byte) 0xD9; ex[2] = (byte) pad; d.setExtra(ex);
                }
                zo.putNextEntry(d); zo.write(data); zo.closeEntry();
            }
            zo.putNextEntry(new ZipEntry("assets/www/index.html")); zo.write(html.getBytes(StandardCharsets.UTF_8)); zo.closeEntry();
        }
    }
    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[65536]; int r;
        while ((r = in.read(buf)) > 0) b.write(buf, 0, r);
        return b.toByteArray();
    }
    static byte[] patch(byte[] m, String from, String to) {
        byte[] f = from.getBytes(StandardCharsets.UTF_16LE), t = to.getBytes(StandardCharsets.UTF_16LE);
        outer: for (int i = 0; i + f.length <= m.length; i++) {
            for (int j = 0; j < f.length; j++) if (m[i + j] != f[j]) continue outer;
            System.arraycopy(t, 0, m, i, t.length);
        }
        return m;
    }
}
