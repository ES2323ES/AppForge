package com.appforge.builder;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** עריכת מחרוזות בקובץ AndroidManifest בינארי (AXML), בלי מגבלת אורך. */
public class Axml {
    public static List<String> strings(byte[] x) {
        ByteBuffer b = ByteBuffer.wrap(x).order(ByteOrder.LITTLE_ENDIAN);
        int po = b.getShort(2) & 0xFFFF;
        if ((b.getShort(po) & 0xFFFF) != 0x0001) throw new IllegalStateException("no string pool");
        int hdr = b.getShort(po + 2) & 0xFFFF, count = b.getInt(po + 8), flags = b.getInt(po + 16), strStart = b.getInt(po + 20);
        boolean utf8 = (flags & 0x100) != 0;
        List<String> list = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            int p = po + strStart + b.getInt(po + hdr + 4 * i);
            list.add(utf8 ? read8(x, p) : read16(b, x, p));
        }
        return list;
    }
    public static byte[] replace(byte[] x, Map<String, String> map) {
        ByteBuffer b = ByteBuffer.wrap(x).order(ByteOrder.LITTLE_ENDIAN);
        int po = b.getShort(2) & 0xFFFF;
        int hdr = b.getShort(po + 2) & 0xFFFF, oldSize = b.getInt(po + 4), count = b.getInt(po + 8), styles = b.getInt(po + 12), flags = b.getInt(po + 16);
        if (styles != 0) throw new IllegalStateException("styles not supported");
        boolean utf8 = (flags & 0x100) != 0;
        List<String> list = strings(x);
        ByteArrayOutputStream data = new ByteArrayOutputStream(); int[] offs = new int[count];
        for (int i = 0; i < count; i++) {
            String s = list.get(i);
            for (Map.Entry<String, String> e : map.entrySet()) s = s.replace(e.getKey(), e.getValue());
            offs[i] = data.size();
            if (utf8) write8(data, s); else write16(data, s);
        }
        while (data.size() % 4 != 0) data.write(0);
        int newStrStart = hdr + 4 * count, newSize = newStrStart + data.size();
        ByteBuffer pool = ByteBuffer.allocate(newSize).order(ByteOrder.LITTLE_ENDIAN);
        pool.put(x, po, hdr);
        pool.putInt(4, newSize); pool.putInt(20, newStrStart);
        pool.position(hdr); for (int o : offs) pool.putInt(o);
        pool.put(data.toByteArray());
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(x, 0, po); out.write(pool.array(), 0, newSize); out.write(x, po + oldSize, x.length - po - oldSize);
        byte[] r = out.toByteArray();
        ByteBuffer.wrap(r).order(ByteOrder.LITTLE_ENDIAN).putInt(4, r.length);
        return r;
    }
    static String read16(ByteBuffer b, byte[] x, int p) {
        int n = b.getShort(p) & 0xFFFF, q = p + 2;
        if ((n & 0x8000) != 0) { n = ((n & 0x7FFF) << 16) | (b.getShort(q) & 0xFFFF); q += 2; }
        return new String(x, q, n * 2, StandardCharsets.UTF_16LE);
    }
    static String read8(byte[] x, int p) {
        int q = p, cl = x[q++] & 0xFF;
        if ((cl & 0x80) != 0) q++;
        int bl = x[q++] & 0xFF;
        if ((bl & 0x80) != 0) bl = ((bl & 0x7F) << 8) | (x[q++] & 0xFF);
        return new String(x, q, bl, StandardCharsets.UTF_8);
    }
    static void write16(ByteArrayOutputStream o, String s) {
        int n = s.length();
        if (n >= 0x8000) { int hi = (n >> 16) | 0x8000; o.write(hi & 0xFF); o.write(hi >> 8); }
        o.write(n & 0xFF); o.write((n >> 8) & 0xFF);
        byte[] d = s.getBytes(StandardCharsets.UTF_16LE); o.write(d, 0, d.length);
        o.write(0); o.write(0);
    }
    static void write8(ByteArrayOutputStream o, String s) {
        byte[] d = s.getBytes(StandardCharsets.UTF_8); int cl = s.length(), bl = d.length;
        if (cl > 0x7F) { o.write((cl >> 8) | 0x80); o.write(cl & 0xFF); } else o.write(cl);
        if (bl > 0x7F) { o.write((bl >> 8) | 0x80); o.write(bl & 0xFF); } else o.write(bl);
        o.write(d, 0, d.length); o.write(0);
    }
}
