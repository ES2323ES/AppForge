package com.appforge.builder;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.os.Build;
import android.content.res.AssetFileDescriptor;
import android.os.Bundle;
import android.webkit.*;
import com.appforge.Bridge;
import com.google.mediapipe.tasks.genai.llminference.LlmInference;
import org.json.JSONObject;
import java.io.*;

public class MainActivity extends Activity {
    WebView w; Bridge bridge; LlmInference llm; boolean gemma; volatile boolean busy;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {   // שומר את סיבת הקריסה להצגה בהפעלה הבאה
            try { PrintWriter pw = new PrintWriter(new File(getFilesDir(), "crash.txt")); e.printStackTrace(pw); pw.close(); } catch (Exception x) {}
            System.exit(2);
        });
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);   // המסך נשאר דלוק בזמן יצירה
        w = new WebView(this); setContentView(w);
        WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient());
        bridge = new Bridge(this);
        w.addJavascriptInterface(bridge, "Forge");
        w.addJavascriptInterface(new Ai(), "Ai");
        w.loadUrl("file:///android_asset/index.html");
    }
    void js(String s) { runOnUiThread(() -> w.evaluateJavascript(s, null)); }

    String modelName() {
        try (InputStream in = getAssets().open("model_name.txt")) { return new String(Packager.readAll(in)).trim(); }
        catch (Exception e) { return ""; }
    }
    static String root(Throwable e) {
        while (e.getCause() != null && e.getCause() != e) e = e.getCause();
        return e.getClass().getSimpleName() + ": " + e.getMessage();
    }
    String[] parts() {   // המודל מפוצל לחלקים model_00.task, model_01.task ...
        try {
            java.util.List<String> l = new java.util.ArrayList<>();
            for (String n : getAssets().list("")) if (n.startsWith("model_") && n.endsWith(".task")) l.add(n);
            java.util.Collections.sort(l); return l.toArray(new String[0]);
        } catch (IOException e) { return new String[0]; }
    }
    String fmt(String p) {
        return gemma ? "<start_of_turn>user\n" + p + "<end_of_turn>\n<start_of_turn>model\n"
            : "<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n<|im_start|>user\n" + p + "<|im_end|>\n<|im_start|>assistant\n";
    }
    void create(String path) throws Exception {
        if (llm != null) { try { llm.close(); } catch (Throwable ignore) {} llm = null; }
        Exception last = null;
        for (int t : new int[]{2048, 1280, 1024}) {   // מנסה הקשר גדול ויורד אם המודל לא תומך
            try {
                llm = LlmInference.createFromOptions(this, LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(t).build());
                js("onModel(true," + t + ")"); return;
            } catch (Exception e) { last = e; }
        }
        throw last;
    }

    class Ai {
        /** טוען את המודל המובנה (מועתק לאחסון הפנימי בהפעלה הראשונה). */
        @JavascriptInterface public void autoLoad() {
            new Thread(() -> {
                try {
                    js("onStep(3,'בודק את קבצי המודל')");
                    String[] ps = parts();
                    if (ps.length == 0) { js("onModel(false,'NOASSET')"); return; }
                    long len = 0;
                    for (String n : ps) try (AssetFileDescriptor fd = getAssets().openFd(n)) { len += fd.getLength(); }
                    File f = new File(getFilesDir(), "model.task");
                    if (!f.exists() || f.length() != len) {
                        File tmp = new File(getFilesDir(), "model.tmp");
                        try (OutputStream o = new FileOutputStream(tmp)) {
                            byte[] b = new byte[1 << 20]; long done = 0; int r, last = -1;
                            for (String n : ps) try (InputStream in = getAssets().open(n)) {
                                while ((r = in.read(b)) > 0) { o.write(b, 0, r); done += r; int p = (int) (done * 100 / len); if (p != last) { last = p; js("onStep(" + p + ",'מעתיק את המודל לאחסון הפנימי')"); } }
                            }
                        }
                        f.delete(); tmp.renameTo(f);
                    }
                    gemma = modelName().toLowerCase().contains("gemma");
                    js("onStep(85,'טוען את המודל לזיכרון (עד דקה)')");
                    create(f.getPath());
                } catch (Throwable e) { js("onModel(false," + JSONObject.quote(String.valueOf(e)) + ")"); }
            }).start();
        }
        /** טעינת מודל חיצוני מנתיב (אופציונלי). */
        @JavascriptInterface public void load(String path) {
            new Thread(() -> {
                try { gemma = path.toLowerCase().contains("gemma"); create(path); }
                catch (Throwable e) { js("onModel(false," + JSONObject.quote(String.valueOf(e)) + ")"); }
            }).start();
        }
        /** סיבת סגירה לא תקינה אחרונה (אם הייתה), להצגה בראש הצ'אט. */
        @JavascriptInterface public String lastExit() {
            try {
                File cf = new File(getFilesDir(), "crash.txt");
                if (cf.exists()) { String t = new String(Packager.readAll(new FileInputStream(cf))); cf.delete(); return "קריסת אפליקציה: " + t.substring(0, Math.min(300, t.length())); }
                if (Build.VERSION.SDK_INT < 30) return "";
                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                java.util.List<ApplicationExitInfo> l = am.getHistoricalProcessExitReasons(getPackageName(), 0, 1);
                if (l.isEmpty()) return "";
                ApplicationExitInfo e = l.get(0); String n;
                switch (e.getReason()) {
                    case ApplicationExitInfo.REASON_LOW_MEMORY: n = "חוסר זיכרון (המערכת סגרה את האפליקציה)"; break;
                    case ApplicationExitInfo.REASON_CRASH_NATIVE: n = "קריסה בקוד נייטיב (כנראה המודל)"; break;
                    case ApplicationExitInfo.REASON_CRASH: n = "קריסת אפליקציה"; break;
                    case ApplicationExitInfo.REASON_ANR: n = "האפליקציה הפסיקה להגיב"; break;
                    default: return "";
                }
                return n + " | " + e.getDescription();
            } catch (Throwable t) { return ""; }
        }
        @JavascriptInterface public boolean ask(String prompt) {
            if (busy || llm == null) return false;
            busy = true;
            new Thread(() -> {
                String res;
                try { res = llm.generateResponse(fmt(prompt)); }
                catch (Throwable e) {
                    try {   // ניסיון חוזר עם בקשה קצרה יותר
                        String small = prompt.substring(Math.max(0, prompt.lastIndexOf("Request:")));
                        res = llm.generateResponse(fmt("Write a complete single-file HTML app in a ```html block. " + small));
                    } catch (Throwable e2) { res = "שגיאה: " + root(e2); }
                }
                busy = false;
                js("onAnswer(" + JSONObject.quote(res) + ")");
            }).start();
            return true;
        }
        @JavascriptInterface public boolean build(String html, String name) {
            if (busy) return false;
            busy = true;
            new Thread(() -> {
                String r;
                try { r = Packager.build(MainActivity.this, html, name, (pct, msg) -> js("onStep(" + pct + "," + JSONObject.quote(msg) + ")")); }
                catch (Throwable e) { r = "!" + root(e); }
                busy = false;
                js("onBuilt(" + JSONObject.quote(r) + ")");
                if (!r.startsWith("!")) bridge.open(r);
            }).start();
            return true;
        }
    }
}
