package com.appforge.builder;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.res.AssetFileDescriptor;
import android.os.Build;
import android.os.Bundle;
import android.webkit.*;
import android.widget.Toast;
import com.appforge.Bridge;
import com.google.mediapipe.tasks.genai.llminference.LlmInference;
import org.json.JSONObject;
import java.io.*;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class MainActivity extends Activity {
    WebView w; Bridge bridge; LlmInference llm; boolean gemma, useStream; volatile boolean busy, renderGone;
    int ctxTokens = 1024; boolean streaming; Method asyncM, sizeM;
    final Object lock = new Object(); final StringBuilder gen = new StringBuilder(); boolean genDone; int genTokens; String genErr;
    File logf; long lastBack;
    static final String PRE = "```html\n<!DOCTYPE html>\n<html lang=\"he\" dir=\"rtl\">\n<head>\n<meta charset=\"utf-8\">\n<style>body{font-family:system-ui;margin:12px}button{padding:10px}</style>\n</head>\n<body>\n";

    // ---------------- יומן תקלות (נכתב לדיסק בכל שורה, גם אם האפליקציה קורסת) ----------------
    synchronized void log(String m) {
        try {
            if (logf.length() > 300000) {
                byte[] all = java.nio.file.Files.readAllBytes(logf.toPath());
                java.nio.file.Files.write(logf.toPath(), java.util.Arrays.copyOfRange(all, all.length - 120000, all.length));
            }
            try (FileOutputStream o = new FileOutputStream(logf, true)) {
                o.write((new java.text.SimpleDateFormat("dd/MM HH:mm:ss.SSS", java.util.Locale.US).format(new java.util.Date()) + "  " + m + "\n").getBytes("UTF-8"));
                o.getFD().sync();
            }
        } catch (Throwable ignore) {}
    }
    String readLog() {
        try { byte[] all = java.nio.file.Files.readAllBytes(logf.toPath()); int f = Math.max(0, all.length - 80000); return new String(all, f, all.length - f, "UTF-8"); }
        catch (Throwable e) { return ""; }
    }
    String mem() {
        Runtime r = Runtime.getRuntime(); ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
        return "זיכרון: java=" + ((r.totalMemory() - r.freeMemory()) >> 20) + "MB native=" + (android.os.Debug.getNativeHeapAllocatedSize() >> 20) + "MB פנוי=" + (mi.availMem >> 20) + "MB נמוך=" + mi.lowMemory;
    }
    static String exitName(int r) {
        switch (r) {
            case 1: return "יציאה רגילה"; case 2: return "נהרגה באות (signal)"; case 3: return "חוסר זיכרון"; case 4: return "קריסת Java";
            case 5: return "קריסה נייטיב (כנראה המודל)"; case 6: return "לא הגיבה (ANR)"; case 7: return "כשל באתחול"; case 9: return "שימוש יתר במשאבים";
            case 10: return "המשתמש סגר"; case 11: return "המשתמש עצר"; case 12: return "תלות נסגרה"; case 13: return "סיבה אחרת"; case 14: return "הוקפאה";
            default: return "קוד " + r;
        }
    }
    String exitLine(ApplicationExitInfo e) {
        return exitName(e.getReason()) + " | status=" + e.getStatus() + " | rss=" + (e.getRss() / 1024) + "MB | " + e.getDescription();
    }
    void logExits() {
        try {
            if (Build.VERSION.SDK_INT < 30) return;
            for (ApplicationExitInfo e : ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getHistoricalProcessExitReasons(getPackageName(), 0, 3))
                log("סגירה קודמת: " + exitLine(e));
        } catch (Throwable ignore) {}
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        logf = new File(getFilesDir(), "appforge-log.txt");
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            log("קריסת Java בשרשור " + t.getName() + ":\n" + android.util.Log.getStackTraceString(e));
            System.exit(2);
        });
        log("=== הפעלה | גרסה 0.3.0 | אנדרואיד " + Build.VERSION.RELEASE + " | " + Build.MODEL + " | " + mem());
        logExits();
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        bridge = new Bridge(this);
        initWeb();
    }
    void initWeb() {
        w = new WebView(this); setContentView(w);
        WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        w.setWebChromeClient(new WebChromeClient());
        w.setWebViewClient(new WebViewClient() {
            // בלי זה, אם המערכת סוגרת את תהליך התצוגה בגלל חוסר זיכרון, כל האפליקציה קורסת
            @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                renderGone = true; log("תהליך התצוגה נסגר (קרס=" + d.didCrash() + "), טוען מחדש | " + mem());
                initWeb();
                try { v.destroy(); } catch (Exception e) {}
                return true;
            }
        });
        if (Build.VERSION.SDK_INT >= 26) w.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        w.addJavascriptInterface(bridge, "Forge");
        w.addJavascriptInterface(new Ai(), "Ai");
        w.loadUrl("file:///android_asset/index.html");
    }
    void js(String s) { runOnUiThread(() -> w.evaluateJavascript(s, null)); }

    /** לחיצה כפולה על "חזור" כדי לצאת */
    @Override public void onBackPressed() {
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) { log("יציאה (לחיצה כפולה)"); finish(); return; }
        lastBack = now;
        Toast.makeText(this, busy ? "המודל עובד כרגע. לחץ שוב כדי לצאת בכל זאת" : "לחץ שוב כדי לצאת", Toast.LENGTH_SHORT).show();
    }
    @Override protected void onDestroy() {
        super.onDestroy();
        if (isFinishing()) { log("האפליקציה נסגרה"); System.exit(0); }   // משחרר את זיכרון המודל
    }

    String modelName() {
        try (InputStream in = getAssets().open("model_name.txt")) { return new String(Packager.readAll(in)).trim(); }
        catch (Exception e) { return ""; }
    }
    static String root(Throwable e) {
        while (e.getCause() != null && e.getCause() != e) e = e.getCause();
        return e.getClass().getSimpleName() + ": " + e.getMessage();
    }
    String[] parts() {   // המודל מפוצל לחלקים model_00.task, model_01.task ...
        try {
            java.util.List<String> l = new java.util.ArrayList<>();
            for (String n : getAssets().list("")) if (n.startsWith("model_") && n.endsWith(".task")) l.add(n);
            java.util.Collections.sort(l); return l.toArray(new String[0]);
        } catch (IOException e) { return new String[0]; }
    }
    String fmt(String p) {
        return gemma ? "<start_of_turn>user\n" + p + "<end_of_turn>\n<start_of_turn>model\n"
            : "<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n<|im_start|>user\n" + p + "<|im_end|>\n<|im_start|>assistant\n";
    }
    int tok(String t) {
        try { if (sizeM != null) return (Integer) sizeM.invoke(llm, t); } catch (Throwable ignore) {}
        return t.length() / 2 + 1;
    }

    // ---- זרימת תוצאות (ניסיוני, דרך reflection) ----
    Object listener(Object p, Method m, Object[] a, boolean result) {
        try {
            String n = m.getName();
            if (n.equals("hashCode")) return System.identityHashCode(p);
            if (n.equals("equals")) return p == a[0];
            if (n.equals("toString")) return "L";
            synchronized (lock) {
                if (result) { gen.append(String.valueOf(a[0])); genTokens++; if (Boolean.TRUE.equals(a[1])) genDone = true; }
                else genErr = String.valueOf(a[0]);
                lock.notifyAll();
            }
        } catch (Throwable ignore) {}
        return null;
    }
    boolean hook(Object bld) {
        boolean ok = false;
        try {
            for (Method m : bld.getClass().getMethods()) {
                if (m.getParameterTypes().length != 1 || !m.getParameterTypes()[0].isInterface()) continue;
                Class<?> it = m.getParameterTypes()[0]; String n = m.getName();
                if (n.equals("setResultListener")) {
                    m.setAccessible(true);
                    m.invoke(bld, Proxy.newProxyInstance(it.getClassLoader(), new Class<?>[]{it}, (p, mm, a) -> listener(p, mm, a, true))); ok = true;
                } else if (n.equals("setErrorListener")) {
                    m.setAccessible(true);
                    m.invoke(bld, Proxy.newProxyInstance(it.getClassLoader(), new Class<?>[]{it}, (p, mm, a) -> listener(p, mm, a, false)));
                }
            }
        } catch (Throwable e) { ok = false; log("hook נכשל: " + root(e)); }
        return ok;
    }
    void cpu(Object bld) {   // מכריח CPU (הכי יציב)
        try {
            for (Method m : bld.getClass().getMethods()) {
                if (!m.getName().equals("setPreferredBackend") || m.getParameterTypes().length != 1 || !m.getParameterTypes()[0].isEnum()) continue;
                for (Object c : m.getParameterTypes()[0].getEnumConstants()) if (c.toString().equals("CPU")) { m.setAccessible(true); m.invoke(bld, c); log("מעבד: CPU"); }
            }
        } catch (Throwable e) { log("בחירת CPU נכשלה: " + root(e)); }
    }
    static int ekv(String s) {   // גודל ה-KV cache נמצא בשם קובץ המודל, למשל ekv1280
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("ekv(\\d+)").matcher(s);
        return m.find() ? Integer.parseInt(m.group(1)) : 0;
    }
    void create(String path, String nameHint) throws Exception {
        if (llm != null) { try { llm.close(); } catch (Throwable ignore) {} llm = null; }
        asyncM = null; sizeM = null; streaming = false;
        try { asyncM = LlmInference.class.getMethod("generateResponseAsync", String.class); } catch (Throwable ignore) {}
        try { sizeM = LlmInference.class.getMethod("sizeInTokens", String.class); } catch (Throwable ignore) {}
        int kv = ekv(nameHint), want = kv > 0 ? Math.min(kv, 1280) : 1024;   // אף פעם לא מעל מה שהמודל בנוי אליו
        int[] tries = want == 1024 ? new int[]{1024} : new int[]{want, 1024};
        log("טוען מודל | " + nameHint + " | kv מהשם=" + kv + " | מצב=" + (useStream ? "זרימה" : "רגיל") + " | " + mem());
        Exception last = null;
        for (int t : tries) {
            try {
                var bld = LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(t);
                cpu(bld);
                boolean st = useStream && asyncM != null && hook(bld);
                llm = LlmInference.createFromOptions(this, bld.build());
                streaming = st; ctxTokens = t;
                log("המודל נטען | הקשר=" + t + " | זרימה=" + st + " | " + mem());
                js("onModel(true," + t + ")"); return;
            } catch (Exception e) { last = e; log("טעינה נכשלה (הקשר " + t + "): " + root(e)); }
        }
        throw last;
    }
    String stream(String full) throws Exception {
        synchronized (lock) { gen.setLength(0); genDone = false; genTokens = 0; genErr = null; }
        asyncM.invoke(llm, full);
        long start = System.currentTimeMillis();
        synchronized (lock) {
            while (!genDone && genErr == null) {
                lock.wait(250);
                js("onGenProgress(" + genTokens + "," + (System.currentTimeMillis() - start) + ")");
            }
            if (genErr != null && gen.length() == 0) throw new IllegalStateException(genErr);
            return gen.toString();
        }
    }
    volatile int hbId;
    void heartbeat(String tag) {
        final int id = ++hbId;   // דופק ליומן כל 3 שניות: אם האפליקציה קורסת, רואים איפה ובאיזה מצב זיכרון
        Thread t = new Thread(() -> {
            long s = System.currentTimeMillis();
            while (busy && hbId == id) {
                log("דופק " + tag + " | " + (System.currentTimeMillis() - s) / 1000 + " שנ' | טוקנים=" + genTokens + " | " + mem());
                try { Thread.sleep(3000); } catch (Exception e) { return; }
            }
        });
        t.setDaemon(true); t.start();
    }
    static String esc(String s) { return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", " "); }
    /** תחילת הדף שנכתבת מראש בתוך התשובה: כוללת את כותרת הבקשה, כדי שהמודל ימשיך לתוך הגוף ולא יסגור את הדף מיד. */
    String buildPre(String req, boolean retry) {
        String t = esc(req.length() > 60 ? req.substring(0, 60) : req).trim();
        return "<!DOCTYPE html>\n<html lang=\"he\" dir=\"rtl\">\n<head>\n<meta charset=\"utf-8\">\n<title>" + t + "</title>\n<style>body{font-family:system-ui;margin:12px}button{padding:10px}</style>\n</head>\n<body>\n<h1>" + t + "</h1>\n" + (retry ? "<div id=\"app\">\n" : "");
    }
    void runGen(String prompt) {
        String res; long t0 = System.currentTimeMillis();
        try {
            boolean retry = prompt.startsWith("[retry]"); if (retry) prompt = prompt.substring(7);
            String p = prompt; boolean cont = prompt.startsWith("Continue the HTML");
            String req = prompt.contains("Request:") ? prompt.substring(prompt.lastIndexOf("Request:") + 8).trim() : "";
            String pre = cont ? "" : buildPre(req, retry);
            if (tok(fmt(p) + pre) > ctxTokens - 300) p = prompt.substring(Math.max(0, prompt.lastIndexOf("Request:")));
            int inTok = tok(fmt(p) + pre);
            if (inTok > ctxTokens - 300) throw new IllegalStateException("הבקשה ארוכה מדי למודל, קצר אותה");
            log("כתיבה התחילה | קלט=" + inTok + " טוקנים | הקשר=" + ctxTokens + " | מצב=" + (streaming ? "זרימה" : "רגיל") + " | " + mem());
            js("onGenStart(" + inTok + "," + (ctxTokens - inTok) + ",'" + (streaming ? "stream" : "sync") + "')");
            heartbeat("כתיבה");
            String gtxt = streaming ? stream(fmt(p) + pre) : llm.generateResponse(fmt(p) + pre);
            res = pre + gtxt;
            log("תשובה (תחילה): " + res.substring(0, Math.min(250, res.length())).replace("\n", " ⏎ "));
            log("תשובה (סוף): " + res.substring(Math.max(0, res.length() - 150)).replace("\n", " ⏎ "));
            log("כתיבה הסתיימה אחרי " + (System.currentTimeMillis() - t0) / 1000 + " שניות | " + res.length() + " תווים");
        } catch (Throwable e) { res = "שגיאה: " + root(e); log("כתיבה נכשלה: " + res); }
        busy = false;
        js("onAnswer(" + JSONObject.quote(res) + ")");
    }

    class Ai {
        /** טוען את המודל המובנה (מועתק לאחסון הפנימי בהפעלה הראשונה). */
        @JavascriptInterface public void autoLoad(boolean stream) {
            new Thread(() -> {
                try {
                    if (llm != null && stream == useStream) { js("onModel(true," + ctxTokens + ")"); return; }   // אחרי טעינה מחדש של התצוגה
                    if (busy) return;
                    useStream = stream;
                    js("onStep(3,'בודק את קבצי המודל')");
                    String[] ps = parts();
                    if (ps.length == 0) { log("אין מודל מובנה"); js("onModel(false,'NOASSET')"); return; }
                    long len = 0;
                    for (String n : ps) try (AssetFileDescriptor fd = getAssets().openFd(n)) { len += fd.getLength(); }
                    File f = new File(getFilesDir(), "model.task");
                    if (!f.exists() || f.length() != len) {
                        log("מעתיק מודל " + (len >> 20) + "MB לאחסון הפנימי");
                        File tmp = new File(getFilesDir(), "model.tmp");
                        try (OutputStream o = new FileOutputStream(tmp)) {
                            byte[] b = new byte[1 << 20]; long done = 0; int r, last = -1;
                            for (String n : ps) try (InputStream in = getAssets().open(n)) {
                                while ((r = in.read(b)) > 0) { o.write(b, 0, r); done += r; int p = (int) (done * 100 / len); if (p != last) { last = p; js("onStep(" + p + ",'מעתיק את המודל לאחסון הפנימי')"); } }
                            }
                        }
                        f.delete(); tmp.renameTo(f);
                        log("העתקת המודל הסתיימה");
                    }
                    String nm = modelName();
                    gemma = nm.toLowerCase().contains("gemma");
                    js("onStep(-1,'טוען את המודל לזיכרון (לשלב הזה אין מדד התקדמות, עד דקה)')");
                    create(f.getPath(), nm);
                } catch (Throwable e) { log("טעינת מודל נכשלה: " + root(e)); js("onModel(false," + JSONObject.quote(String.valueOf(e)) + ")"); }
            }).start();
        }
        /** טעינת מודל חיצוני מנתיב (אופציונלי). */
        @JavascriptInterface public void load(String path) {
            new Thread(() -> {
                try { gemma = path.toLowerCase().contains("gemma"); js("onStep(-1,'טוען את המודל לזיכרון (לשלב הזה אין מדד התקדמות)')"); create(path, path); }
                catch (Throwable e) { log("טעינת מודל חיצוני נכשלה: " + root(e)); js("onModel(false," + JSONObject.quote(String.valueOf(e)) + ")"); }
            }).start();
        }
        /** הודעה על סגירה לא תקינה של ההפעלה הקודמת (אם הייתה). */
        @JavascriptInterface public String lastExit() {
            try {
                if (renderGone) { renderGone = false; return "מסך הממשק נסגר על ידי המערכת בגלל חוסר זיכרון ונטען מחדש"; }
                if (Build.VERSION.SDK_INT < 30) return "";
                java.util.List<ApplicationExitInfo> l = ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getHistoricalProcessExitReasons(getPackageName(), 0, 1);
                if (l.isEmpty()) return "";
                int r = l.get(0).getReason();
                if (r == 1 || r == 10 || r == 11 || r == 15 || r == 16) return "";   // יציאות רגילות
                return "בפעם הקודמת האפליקציה נסגרה: " + exitLine(l.get(0)) + "  (פרטים בלשונית יומן)";
            } catch (Throwable t) { return ""; }
        }
        @JavascriptInterface public void log(String m) { MainActivity.this.log("[ממשק] " + m); }
        @JavascriptInterface public String readLog() { return MainActivity.this.readLog(); }
        @JavascriptInterface public void clearLog() { try { new FileOutputStream(logf).close(); } catch (Throwable ignore) {} }
        @JavascriptInterface public void shareLog() { bridge.share(logf.getPath()); }
        @JavascriptInterface public boolean ask(String prompt) {
            if (busy || llm == null) return false;
            busy = true;
            new Thread(() -> runGen(prompt)).start();
            return true;
        }
        @JavascriptInterface public boolean build(String html, String name) {
            if (busy) return false;
            busy = true;
            new Thread(() -> {
                String r; long t0 = System.currentTimeMillis();
                log("בנייה התחילה | " + html.length() + " תווים | " + mem());
                heartbeat("בנייה");
                try { r = Packager.build(MainActivity.this, html, name, (pct, msg) -> { log("בנייה " + pct + "% " + msg); js("onStep(" + pct + "," + JSONObject.quote(msg) + ")"); }); }
                catch (Throwable e) { r = "!" + root(e); log("בנייה נכשלה:\n" + android.util.Log.getStackTraceString(e)); }
                busy = false;
                log("בנייה הסתיימה אחרי " + (System.currentTimeMillis() - t0) / 1000 + " שניות | " + r);
                js("onBuilt(" + JSONObject.quote(r) + ")");
                if (!r.startsWith("!")) bridge.open(r);
            }).start();
            return true;
        }
    }
}
