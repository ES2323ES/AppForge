package com.appforge.builder;

import android.app.Activity;
import android.content.res.AssetFileDescriptor;
import android.os.Bundle;
import android.webkit.*;
import com.appforge.Bridge;
import com.google.mediapipe.tasks.genai.llminference.LlmInference;
import org.json.JSONObject;
import java.io.*;

public class MainActivity extends Activity {
    WebView w; Bridge bridge; LlmInference llm; boolean gemma;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this); setContentView(w);
        WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient());
        bridge = new Bridge(this);
        w.addJavascriptInterface(bridge, "Forge");
        w.addJavascriptInterface(new Ai(), "Ai");
        w.loadUrl("file:///android_asset/index.html");
    }
    void js(String s) { runOnUiThread(() -> w.evaluateJavascript(s, null)); }

    String modelName() {
        try (InputStream in = getAssets().open("model_name.txt")) { return new String(Packager.readAll(in)).trim(); }
        catch (Exception e) { return ""; }
    }
    String fmt(String p) {
        return gemma ? "<start_of_turn>user\n" + p + "<end_of_turn>\n<start_of_turn>model\n"
            : "<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n<|im_start|>user\n" + p + "<|im_end|>\n<|im_start|>assistant\n";
    }
    void create(String path) throws Exception {
        Exception last = null;
        for (int t : new int[]{4096, 2048, 1024}) {   // מנסה הקשר גדול ויורד אם המודל לא תומך
            try {
                llm = LlmInference.createFromOptions(this, LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(t).build());
                js("onModel(true," + t + ")"); return;
            } catch (Exception e) { last = e; }
        }
        throw last;
    }

    class Ai {
        /** טוען את המודל המובנה (מועתק לאחסון הפנימי בהפעלה הראשונה). */
        @JavascriptInterface public void autoLoad() {
            new Thread(() -> {
                try {
                    long len;
                    try (AssetFileDescriptor fd = getAssets().openFd("model.task")) { len = fd.getLength(); }
                    catch (IOException e) { js("onModel(false,'NOASSET')"); return; }
                    File f = new File(getFilesDir(), "model.task");
                    if (!f.exists() || f.length() != len) {
                        File tmp = new File(getFilesDir(), "model.tmp");
                        try (InputStream in = getAssets().open("model.task"); OutputStream o = new FileOutputStream(tmp)) {
                            byte[] b = new byte[1 << 20]; long done = 0; int r, last = -1;
                            while ((r = in.read(b)) > 0) { o.write(b, 0, r); done += r; int p = (int) (done * 100 / len); if (p != last) { last = p; js("onProgress(" + p + ")"); } }
                        }
                        f.delete(); tmp.renameTo(f);
                    }
                    gemma = modelName().toLowerCase().contains("gemma");
                    create(f.getPath());
                } catch (Throwable e) { js("onModel(false," + JSONObject.quote(String.valueOf(e)) + ")"); }
            }).start();
        }
        /** טעינת מודל חיצוני מנתיב (אופציונלי). */
        @JavascriptInterface public void load(String path) {
            new Thread(() -> {
                try { gemma = path.toLowerCase().contains("gemma"); create(path); }
                catch (Throwable e) { js("onModel(false," + JSONObject.quote(String.valueOf(e)) + ")"); }
            }).start();
        }
        @JavascriptInterface public void ask(String prompt) {
            new Thread(() -> {
                try { js("onAnswer(" + JSONObject.quote(llm.generateResponse(fmt(prompt))) + ")"); }
                catch (Throwable e) { js("onAnswer(" + JSONObject.quote("שגיאה: " + e) + ")"); }
            }).start();
        }
        @JavascriptInterface public void build(String html, String name) {
            new Thread(() -> {
                try { String p = Packager.build(MainActivity.this, html, name); js("onBuilt(" + JSONObject.quote(p) + ")"); bridge.open(p); }
                catch (Throwable e) { js("onBuilt(" + JSONObject.quote("!" + e) + ")"); }
            }).start();
        }
    }
}
