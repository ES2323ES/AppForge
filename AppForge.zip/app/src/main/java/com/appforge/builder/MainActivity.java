package com.appforge.builder;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import com.appforge.Bridge;
import com.google.mediapipe.tasks.genai.llminference.LlmInference;
import org.json.JSONObject;

public class MainActivity extends Activity {
    WebView w; Bridge bridge; LlmInference llm;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this); setContentView(w);
        WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient());
        bridge = new Bridge(this);
        w.addJavascriptInterface(bridge, "Forge");
        w.addJavascriptInterface(new Ai(), "Ai");
        w.loadUrl("file:///android_asset/index.html");
    }
    void js(String s) { runOnUiThread(() -> w.evaluateJavascript(s, null)); }

    class Ai {
        @JavascriptInterface public void load(String path) {
            new Thread(() -> {
                try {
                    llm = LlmInference.createFromOptions(MainActivity.this,
                        LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(3000).build());
                    js("onModel(true,'')");
                } catch (Throwable e) { js("onModel(false," + JSONObject.quote(String.valueOf(e)) + ")"); }
            }).start();
        }
        @JavascriptInterface public void ask(String prompt) {
            new Thread(() -> {
                try { js("onAnswer(" + JSONObject.quote(llm.generateResponse("<start_of_turn>user\n" + prompt + "<end_of_turn>\n<start_of_turn>model\n")) + ")"); }
                catch (Throwable e) { js("onAnswer(" + JSONObject.quote("שגיאה: " + e) + ")"); }
            }).start();
        }
        @JavascriptInterface public void build(String html, String name) {
            new Thread(() -> {
                try { String p = Packager.build(MainActivity.this, html, name); js("onBuilt(" + JSONObject.quote(p) + ")"); bridge.open(p); }
                catch (Throwable e) { js("onBuilt(" + JSONObject.quote("!" + e) + ")"); }
            }).start();
        }
    }
}
