package com.appforge.builder;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.res.AssetFileDescriptor;
import android.os.Build;
import android.os.Bundle;
import android.webkit.*;
import com.appforge.Bridge;
import com.google.mediapipe.tasks.genai.llminference.LlmInference;
import org.json.JSONObject;
import java.io.*;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class MainActivity extends Activity {
    WebView w; Bridge bridge; LlmInference llm; boolean gemma; volatile boolean busy, renderGone;
    int ctxTokens = 1024; boolean streaming; Method asyncM, sizeM;
    final Object lock = new Object(); final StringBuilder gen = new StringBuilder(); boolean genDone; int genTokens; String genErr;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {   // שומר את סיבת הקריסה להצגה בהפעלה הבאה
            try { PrintWriter pw = new PrintWriter(new File(getFilesDir(), "crash.txt")); e.printStackTrace(pw); pw.close(); } catch (Exception x) {}
            System.exit(2);
        });
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        bridge = new Bridge(this);
        initWeb();
    }
    void initWeb() {
        w = new WebView(this); setContentView(w);
        WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        w.setWebChromeClient(new WebChromeClient());
        w.setWebViewClient(new WebViewClient() {
            // בלי זה, אם המערכת סוגרת את תהליך התצוגה בגלל חוסר זיכרון, כל האפליקציה קורסת
            @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                renderGone = true;
                initWeb();
                try { v.destroy(); } catch (Exception e) {}
                return true;
            }
        });
        if (Build.VERSION.SDK_INT >= 26) w.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        w.addJavascriptInterface(bridge, "Forge");
        w.addJavascriptInterface(new Ai(), "Ai");
        w.loadUrl("file:///android_asset/index.html");
    }
    void js(String s) { runOnUiThread(() -> w.evaluateJavascript(s, null)); }

    String modelName() {
        try (InputStream in = getAssets().open("model_name.txt")) { return new String(Packager.readAll(in)).trim(); }
        catch (Exception e) { return ""; }
    }
    static String root(Throwable e) {
        while (e.getCause() != null && e.getCause() != e) e = e.getCause();
        return e.getClass().getSimpleName() + ": " + e.getMessage();
    }
    String[] parts() {   // המודל מפוצל לחלקים model_00.task, model_01.task ...
        try {
            java.util.List<String> l = new java.util.ArrayList<>();
            for (String n : getAssets().list("")) if (n.startsWith("model_") && n.endsWith(".task")) l.add(n);
            java.util.Collections.sort(l); return l.toArray(new String[0]);
        } catch (IOException e) { return new String[0]; }
    }
    String fmt(String p) {
        return gemma ? "<start_of_turn>user\n" + p + "<end_of_turn>\n<start_of_turn>model\n"
            : "<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n<|im_start|>user\n" + p + "<|im_end|>\n<|im_start|>assistant\n";
    }
    int tok(String t) {   // ספירת טוקנים אמיתית אם הספרייה תומכת, אחרת הערכה שמרנית
        try { if (sizeM != null) return (Integer) sizeM.invoke(llm, t); } catch (Throwable ignore) {}
        return t.length() / 2 + 1;
    }

    // ---- הזרמת תוצאות מהמודל (דרך reflection, כדי שהבנייה לא תישבר אם הספרייה שונה) ----
    Object listener(Object p, Method m, Object[] a, boolean result) {
        String n = m.getName();
        if (n.equals("hashCode")) return System.identityHashCode(p);
        if (n.equals("equals")) return p == a[0];
        if (n.equals("toString")) return "L";
        synchronized (lock) {
            if (result) { gen.append(String.valueOf(a[0])); genTokens++; if (Boolean.TRUE.equals(a[1])) genDone = true; }
            else genErr = String.valueOf(a[0]);
            lock.notifyAll();
        }
        return null;
    }
    boolean hook(Object bld) {
        boolean ok = false;
        try {
            for (Method m : bld.getClass().getMethods()) {
                if (m.getParameterTypes().length != 1 || !m.getParameterTypes()[0].isInterface()) continue;
                Class<?> it = m.getParameterTypes()[0]; String n = m.getName();
                if (n.equals("setResultListener")) {
                    m.setAccessible(true);
                    m.invoke(bld, Proxy.newProxyInstance(it.getClassLoader(), new Class<?>[]{it}, (p, mm, a) -> listener(p, mm, a, true))); ok = true;
                } else if (n.equals("setErrorListener")) {
                    m.setAccessible(true);
                    m.invoke(bld, Proxy.newProxyInstance(it.getClassLoader(), new Class<?>[]{it}, (p, mm, a) -> listener(p, mm, a, false)));
                }
            }
        } catch (Throwable e) { ok = false; }
        return ok;
    }
    void create(String path) throws Exception {
        if (llm != null) { try { llm.close(); } catch (Throwable ignore) {} llm = null; }
        asyncM = null; sizeM = null; streaming = false;
        try { asyncM = LlmInference.class.getMethod("generateResponseAsync", String.class); } catch (Throwable ignore) {}
        try { sizeM = LlmInference.class.getMethod("sizeInTokens", String.class); } catch (Throwable ignore) {}
        Exception last = null;
        for (int t : new int[]{2048, 1280, 1024}) {
            try {
                var bld = LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(t);
                boolean st = asyncM != null && hook(bld);
                llm = LlmInference.createFromOptions(this, bld.build());
                streaming = st; ctxTokens = t;
                js("onModel(true," + t + ")"); return;
            } catch (Exception e) { last = e; }
        }
        throw last;
    }
    String stream(String full) throws Exception {
        synchronized (lock) { gen.setLength(0); genDone = false; genTokens = 0; genErr = null; }
        asyncM.invoke(llm, full);
        long start = System.currentTimeMillis(), lastMove = start; int seen = 0;
        synchronized (lock) {
            while (!genDone && genErr == null) {
                lock.wait(250);
                long now = System.currentTimeMillis();
                if (genTokens != seen) { seen = genTokens; lastMove = now; }
                else if (now - lastMove > 180000) throw new IllegalStateException("המודל לא מגיב");
                js("onGenProgress(" + genTokens + "," + (now - start) + ")");
            }
            if (genErr != null && gen.length() == 0) throw new IllegalStateException(genErr);
            return gen.toString();
        }
    }
    void runGen(String prompt) {
        String res;
        try {
            String p = prompt;
            if (tok(fmt(p)) > ctxTokens - 300) p = prompt.substring(Math.max(0, prompt.lastIndexOf("Request:")));
            int inTok = tok(fmt(p));
            if (inTok > ctxTokens - 300) throw new IllegalStateException("הבקשה ארוכה מדי למודל, קצר אותה");
            js("onGenStart(" + inTok + "," + (ctxTokens - inTok) + ",'" + (streaming ? "stream" : "sync") + "')");
            res = streaming ? stream(fmt(p)) : llm.generateResponse(fmt(p));
        } catch (Throwable e) { res = "שגיאה: " + root(e); }
        busy = false;
        js("onAnswer(" + JSONObject.quote(res) + ")");
    }

    class Ai {
        /** טוען את המודל המובנה (מועתק לאחסון הפנימי בהפעלה הראשונה). */
        @JavascriptInterface public void autoLoad() {
            new Thread(() -> {
                try {
                    if (llm != null) { js("onModel(true," + ctxTokens + ")"); return; }   // אחרי טעינה מחדש של התצוגה
                    js("onStep(3,'בודק את קבצי המודל')");
                    String[] ps = parts();
                    if (ps.length == 0) { js("onModel(false,'NOASSET')"); return; }
                    long len = 0;
                    for (String n : ps) try (AssetFileDescriptor fd = getAssets().openFd(n)) { len += fd.getLength(); }
                    File f = new File(getFilesDir(), "model.task");
                    if (!f.exists() || f.length() != len) {
                        File tmp = new File(getFilesDir(), "model.tmp");
                        try (OutputStream o = new FileOutputStream(tmp)) {
                            byte[] b = new byte[1 << 20]; long done = 0; int r, last = -1;
                            for (String n : ps) try (InputStream in = getAssets().open(n)) {
                                while ((r = in.read(b)) > 0) { o.write(b, 0, r); done += r; int p = (int) (done * 100 / len); if (p != last) { last = p; js("onStep(" + p + ",'מעתיק את המודל לאחסון הפנימי')"); } }
                            }
                        }
                        f.delete(); tmp.renameTo(f);
                    }
                    gemma = modelName().toLowerCase().contains("gemma");
                    js("onStep(-1,'טוען את המודל לזיכרון (לשלב הזה אין מדד התקדמות, עד דקה)')");
                    create(f.getPath());
                } catch (Throwable e) { js("onModel(false," + JSONObject.quote(String.valueOf(e)) + ")"); }
            }).start();
        }
        /** טעינת מודל חיצוני מנתיב (אופציונלי). */
        @JavascriptInterface public void load(String path) {
            new Thread(() -> {
                try { gemma = path.toLowerCase().contains("gemma"); js("onStep(-1,'טוען את המודל לזיכרון (לשלב הזה אין מדד התקדמות)')"); create(path); }
                catch (Throwable e) { js("onModel(false," + JSONObject.quote(String.valueOf(e)) + ")"); }
            }).start();
        }
        /** סיבת סגירה לא תקינה אחרונה (אם הייתה), להצגה בראש הצ'אט. */
        @JavascriptInterface public String lastExit() {
            try {
                if (renderGone) { renderGone = false; return "מסך הממשק נסגר על ידי המערכת בגלל חוסר זיכרון ונטען מחדש"; }
                File cf = new File(getFilesDir(), "crash.txt");
                if (cf.exists()) { String t = new String(Packager.readAll(new FileInputStream(cf))); cf.delete(); return "קריסת אפליקציה: " + t.substring(0, Math.min(300, t.length())); }
                if (Build.VERSION.SDK_INT < 30) return "";
                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                java.util.List<ApplicationExitInfo> l = am.getHistoricalProcessExitReasons(getPackageName(), 0, 1);
                if (l.isEmpty()) return "";
                ApplicationExitInfo e = l.get(0); String n;
                switch (e.getReason()) {
                    case ApplicationExitInfo.REASON_LOW_MEMORY: n = "חוסר זיכרון (המערכת סגרה את האפליקציה)"; break;
                    case ApplicationExitInfo.REASON_CRASH_NATIVE: n = "קריסה בקוד נייטיב (כנראה המודל)"; break;
                    case ApplicationExitInfo.REASON_CRASH: n = "קריסת אפליקציה"; break;
                    case ApplicationExitInfo.REASON_ANR: n = "האפליקציה הפסיקה להגיב"; break;
                    default: return "";
                }
                return n + " | " + e.getDescription();
            } catch (Throwable t) { return ""; }
        }
        @JavascriptInterface public boolean ask(String prompt) {
            if (busy || llm == null) return false;
            busy = true;
            new Thread(() -> runGen(prompt)).start();
            return true;
        }
        @JavascriptInterface public boolean build(String html, String name) {
            if (busy) return false;
            busy = true;
            new Thread(() -> {
                String r;
                try { r = Packager.build(MainActivity.this, html, name, (pct, msg) -> js("onStep(" + pct + "," + JSONObject.quote(msg) + ")")); }
                catch (Throwable e) { r = "!" + root(e); }
                busy = false;
                js("onBuilt(" + JSONObject.quote(r) + ")");
                if (!r.startsWith("!")) bridge.open(r);
            }).start();
            return true;
        }
    }
}
