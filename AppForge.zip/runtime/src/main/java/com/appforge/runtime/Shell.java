package com.appforge.runtime;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import com.appforge.Bridge;

public class Shell extends Activity {
    WebView w;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this); setContentView(w);
        WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient());
        w.addJavascriptInterface(new Bridge(this), "Forge");
        w.loadUrl("file:///android_asset/www/index.html");
    }
    @Override public void onBackPressed() { if (w.canGoBack()) w.goBack(); else super.onBackPressed(); }
}
