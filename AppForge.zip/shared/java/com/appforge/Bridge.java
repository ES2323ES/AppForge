package com.appforge;

import android.app.Activity;
import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.util.Size;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.zip.*;

/** גשר עשיר בין JavaScript למערכת. מנוצל כ-Forge בתוך כל אפליקציה. כל הפונקציות מחזירות JSON (או מחרוזת). */
public class Bridge {
    interface T { Object run() throws Exception; }
    final Activity a;
    public Bridge(Activity a) { this.a = a; }

    String go(T t) {
        try { Object o = t.run(); return o == null ? "{\"ok\":true}" : o.toString(); }
        catch (Exception e) { return "{\"error\":" + JSONObject.quote(String.valueOf(e.getMessage())) + "}"; }
    }

    // ---- הרשאות ומידע ----
    @JavascriptInterface public boolean hasAll() { return Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager(); }
    @JavascriptInterface public String home() { return Environment.getExternalStorageDirectory().getPath(); }
    @JavascriptInterface public String perms() {
        a.runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager())
                a.startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + a.getPackageName())));
            if (Build.VERSION.SDK_INT >= 33)
                a.requestPermissions(new String[]{"android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO"}, 1);
            else
                a.requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}, 1);
        });
        return "{\"ok\":true}";
    }
    @JavascriptInterface public String storage() {
        return go(() -> { File f = Environment.getExternalStorageDirectory(); return new JSONObject().put("total", f.getTotalSpace()).put("free", f.getFreeSpace()); });
    }
    @JavascriptInterface public void toast(String s) { a.runOnUiThread(() -> Toast.makeText(a, s, Toast.LENGTH_SHORT).show()); }
    @JavascriptInterface public void clip(String s) {
        a.runOnUiThread(() -> ((ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("t", s)));
    }

    // ---- קבצים ----
    JSONObject meta(File f) throws JSONException {
        return new JSONObject().put("name", f.getName()).put("path", f.getPath()).put("dir", f.isDirectory())
                .put("size", f.length()).put("mod", f.lastModified()).put("mime", mime(f));
    }
    String mime(File f) {
        if (f.isDirectory()) return "dir";
        String n = f.getName().toLowerCase(); int i = n.lastIndexOf('.');
        String e = i < 0 ? "" : n.substring(i + 1);
        if (e.equals("apk")) return "application/vnd.android.package-archive";
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(e);
        return m == null ? "application/octet-stream" : m;
    }
    @JavascriptInterface public String list(String p) {
        return go(() -> { JSONArray r = new JSONArray(); File[] fs = new File(p).listFiles(); if (fs != null) for (File f : fs) r.put(meta(f)); return r; });
    }
    @JavascriptInterface public String info(String p) { return go(() -> meta(new File(p))); }
    @JavascriptInterface public String search(String root, String q) {
        return go(() -> { JSONArray r = new JSONArray(); find(new File(root), q.toLowerCase(), r); return r; });
    }
    void find(File d, String q, JSONArray r) throws JSONException {
        File[] fs = d.listFiles(); if (fs == null) return;
        for (File f : fs) { if (r.length() >= 500) return; if (f.getName().toLowerCase().contains(q)) r.put(meta(f)); if (f.isDirectory()) find(f, q, r); }
    }
    @JavascriptInterface public String mkdir(String p) { return go(() -> { if (!new File(p).mkdirs()) throw new IOException("mkdir"); return null; }); }
    @JavascriptInterface public String rename(String p, String name) {
        return go(() -> { File f = new File(p); if (!f.renameTo(new File(f.getParentFile(), name))) throw new IOException("rename"); return null; });
    }
    @JavascriptInterface public String delete(String p) { return go(() -> { del(new File(p)); return null; }); }
    void del(File f) { File[] c = f.listFiles(); if (c != null) for (File x : c) del(x); f.delete(); }
    @JavascriptInterface public String copy(String s, String d) { return go(() -> { cp(new File(s), new File(d)); return null; }); }
    void cp(File s, File d) throws IOException {
        if (s.isDirectory()) { d.mkdirs(); File[] c = s.listFiles(); if (c != null) for (File x : c) cp(x, new File(d, x.getName())); }
        else Files.copy(s.toPath(), d.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }
    @JavascriptInterface public String move(String s, String d) {
        return go(() -> { File f = new File(s), t = new File(d); if (!f.renameTo(t)) { cp(f, t); del(f); } return null; });
    }
    @JavascriptInterface public String readText(String p) {
        return go(() -> new JSONObject().put("text", new String(Files.readAllBytes(Paths.get(p)), StandardCharsets.UTF_8)));
    }
    @JavascriptInterface public String writeText(String p, String t) {
        return go(() -> { Files.write(Paths.get(p), t.getBytes(StandardCharsets.UTF_8)); return null; });
    }
    @JavascriptInterface public String zip(String jsonPaths, String out) {
        return go(() -> {
            JSONArray ps = new JSONArray(jsonPaths);
            try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(out))) {
                for (int i = 0; i < ps.length(); i++) { File f = new File(ps.getString(i)); addZ(z, f, f.getName()); }
            }
            return null;
        });
    }
    void addZ(ZipOutputStream z, File f, String n) throws IOException {
        if (f.isDirectory()) { File[] c = f.listFiles(); if (c != null) for (File x : c) addZ(z, x, n + "/" + x.getName()); }
        else { z.putNextEntry(new ZipEntry(n)); Files.copy(f.toPath(), z); z.closeEntry(); }
    }
    @JavascriptInterface public String unzip(String zip, String dest) {
        return go(() -> {
            File d = new File(dest); d.mkdirs();
            try (ZipInputStream z = new ZipInputStream(new FileInputStream(zip))) {
                ZipEntry e;
                while ((e = z.getNextEntry()) != null) {
                    File t = new File(d, e.getName());
                    if (!t.getCanonicalPath().startsWith(d.getCanonicalPath())) throw new IOException("bad path");
                    if (e.isDirectory()) t.mkdirs();
                    else { t.getParentFile().mkdirs(); Files.copy(z, t.toPath(), StandardCopyOption.REPLACE_EXISTING); }
                }
            }
            return null;
        });
    }

    // ---- פתיחה ושיתוף ----
    Uri uri(String p) { return FileProvider.getUriForFile(a, a.getPackageName() + ".fp", new File(p)); }
    @JavascriptInterface public String open(String p) {
        return go(() -> {
            Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(uri(p), mime(new File(p)))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i); return null;
        });
    }
    @JavascriptInterface public String share(String p) {
        return go(() -> {
            Intent i = new Intent(Intent.ACTION_SEND).setType(mime(new File(p))).putExtra(Intent.EXTRA_STREAM, uri(p))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            a.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return null;
        });
    }

    // ---- גלריה ----
    /** video=false: תמונות, true: סרטונים. ממוין מהחדש לישן. כל פריט כולל album. */
    @JavascriptInterface public String media(boolean video) {
        return go(() -> {
            Uri u = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            String[] pr = {MediaStore.MediaColumns.DATA, MediaStore.MediaColumns.BUCKET_DISPLAY_NAME, MediaStore.MediaColumns.DATE_MODIFIED, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DISPLAY_NAME};
            JSONArray r = new JSONArray();
            try (Cursor c = a.getContentResolver().query(u, pr, null, null, MediaStore.MediaColumns.DATE_MODIFIED + " DESC")) {
                while (c != null && c.moveToNext())
                    r.put(new JSONObject().put("path", c.getString(0)).put("album", c.getString(1)).put("mod", c.getLong(2) * 1000)
                            .put("size", c.getLong(3)).put("name", c.getString(4)).put("video", video));
            }
            return r;
        });
    }
    /** תמונה ממוזערת כ-data URL. px = הצלע הארוכה. עובד גם לסרטונים. */
    @JavascriptInterface public String thumb(String p, int px) {
        try {
            Bitmap b;
            if (mime(new File(p)).startsWith("video")) b = ThumbnailUtils.createVideoThumbnail(new File(p), new Size(px, px), null);
            else {
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true; BitmapFactory.decodeFile(p, o);
                o.inSampleSize = Math.max(1, Math.max(o.outWidth, o.outHeight) / px); o.inJustDecodeBounds = false;
                b = BitmapFactory.decodeFile(p, o);
            }
            ByteArrayOutputStream s = new ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 80, s);
            return "data:image/jpeg;base64," + Base64.encodeToString(s.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) { return ""; }
    }
}
